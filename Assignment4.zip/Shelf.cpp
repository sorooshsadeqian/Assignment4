#include "Shelf.hpp"

using namespace std;

void Shelf::add_book(Book* new_book) {
    books.push_back(new_book);
}

void Shelf::sort_books() {
    sort(books.begin(), books.end(), sort_by_title);
}

void Shelf::print_book_info(int id) {
    Author* author = books[id]->get_author();
    cout << "id: " << books[id]->get_id() << endl
         << "Title: " << books[id]->get_title() << endl
         << "Genre: " << books[id]->get_genre() << endl
         << "Author: " << author->get_name() << endl
         << "***" << endl;
}

void Shelf::print_by_genre_priority(string genre) {
    for (int i = 0; i < books.size(); i++) {
        if (books[i]->get_genre() == genre) {
            print_book_info(i);
        }
    }

    for (int i = 0; i < books.size(); i++) {
        if (books[i]->get_genre() == genre) {
            continue;
        }

        print_book_info(i);
    }
}