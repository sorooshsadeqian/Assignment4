#ifndef SHELF_HPP
#define SHELF_HPP "SHELF_HPP"

#include <vector>
#include <string>
#include <iostream>
#include "Book.hpp"
#include "functions.hpp"
#include <algorithm>

class Shelf {
public:
    void add_book(Book* new_book);
    void sort_books();
    void print_by_genre_priority(std::string genre);
    void print_book_info(int id);
private:
    std::vector<Book*> books;
};

#endif