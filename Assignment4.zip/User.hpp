#ifndef USER_HPP
#define USER_HPP "USER_HPP"

#include <string>
#include <vector>
#include "Date.hpp"
#include "Shelf.hpp"

class Date;
class Author;
   
class User {
public:
    User(int id, std::string name, std::string place_of_birth, Date* member_since, std::vector<Author*> favorite_authors, std::vector<std::string> favorite_genres);
    void add_shelf(Shelf* new_shelf);
    int get_id();
    Shelf* get_shelf(int shelf_type);
private:
    int id;
    std::string name;
    std::string place_of_birth;
    Date* member_since;
    std::vector<Author*> favorite_authors;
    std::vector<std::string> favorite_genres;
    std::vector<Shelf*> shelves; //0=want 1=currently 2=read
};

#endif