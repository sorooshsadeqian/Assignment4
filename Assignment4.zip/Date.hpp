#ifndef DATE_HPP
#define DATE_HPP "DATE_HPP"

#include <string>
#include <vector>
#include <iostream>
#include "functions.hpp"

class Date {
public:
    Date(std::string month, int day, int year);
    Date(std::string);
    void print();
private:
    std::string month;
    int day;
    int year;
};

#endif