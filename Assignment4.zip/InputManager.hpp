#ifndef INPUTMANAGER_HPP
#define INPUTMANAGER_HPP "INPUTMANAGER"

#define WANT_TO_READ 0
#define CURRENTLY_READING 1
#define READ 2

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include "Author.hpp"
#include "Book.hpp"
#include "Storage.hpp"
#include "functions.hpp"

class InputManager {
public:
    InputManager(Storage* storage);
    void take_input();
    void show_author_info(int author_id);
    void show_sorted_shelf(int user_id, int shelf_type, std::string genre);
    double calculate_user_credit(int user_id);
private:
    Storage* storage;
};

#endif