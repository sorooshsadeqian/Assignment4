#include "Review.hpp"

Review::Review(int id, Book* book, User* user, int rating, Date* date, int number_of_likes) {
    this->id = id;
    this->book = book;
    this->user = user;
    this->rating = rating;
    this->number_of_likes = number_of_likes;
}

int Review::get_number_of_likes() {
    return number_of_likes;
}

int Review::get_user_id() {
    int user_id = user->get_id();
    return user_id;
}