#ifndef BOOK_HPP
#define BOOK_HPP "BOOK_HPP"

#include <string>
#include "Author.hpp"   

class Book {
public:
    Book(int id, std::string title, Author* author, std::string genre);
    int get_id();
    int get_author_id();
    std::string get_title();
    Author* get_author();
    std::string get_genre();
private:
    int id;
    std::string title;
    Author* author;
    std::string genre;
};

#endif