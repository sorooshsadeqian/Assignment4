#include "Book.hpp"

using namespace std;

Book::Book(int id, string title, Author* author, string genre) {
    this->id = id;
    this-> title = title;
    this->author = author;
    this->genre = genre;
}

int Book::get_id() {
    return id;
}

int Book::get_author_id() {
    int author_id = author->get_id();
    return author_id;
}

Author* Book::get_author() {
    return author;
}

string Book::get_title() {
    return title;
}

string Book::get_genre() {
    return genre;
}