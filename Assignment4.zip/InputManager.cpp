#include "InputManager.hpp"

using namespace std;

InputManager::InputManager(Storage* storage) {
    this->storage = storage;
}

void InputManager::show_author_info(int author_id) {
    Author* author = storage->get_author_by_id(author_id);
    vector<Book*> author_books = storage->get_author_books(author_id);
    cout << "id: " << author->get_id() << endl
         << "Name: " << author->get_name() << endl
         << "Place Of Birth: " << author->get_place_of_birth() << endl
         << "Member Since: ";
    Date* membership_date = author->get_membership_date();
    membership_date->print();
    vector<string> genres = author->get_genres();
    cout << "Genres: ";
    for (int i = 0; i < genres.size(); i++) {
            if (i == genres.size() - 1) {
                cout << genres[i];
            } else {
                cout << genres[i] << ',' << ' ';
            }
        
    }

    cout << endl << "Books:" << endl;
    for (int i = 0; i < author_books.size(); i++) {
        cout << "id: " << author_books[i]->get_id() << ' ' << "Title: " << author_books[i]->get_title() << endl;
    }
    
}

void InputManager::show_sorted_shelf(int user_id, int shelf_type, string genre) {
    User* user = storage->get_user_by_id(user_id);
    Shelf* shelf = user->get_shelf(shelf_type);
    shelf->sort_books();
    shelf->print_by_genre_priority(genre);
}

double InputManager::calculate_user_credit(int user_id) {
    double total_likes = storage->calculate_total_likes();
    double total_reviews = storage->get_number_of_reviews();
    double number_of_user_review_likes = storage->calculate_uesr_reviews_likes(user_id);
    double number_of_user_reviews = storage->get_number_of_user_reviews(user_id);
    double user_credit = 0.5 * ((number_of_user_review_likes/total_likes) + (number_of_user_reviews/total_reviews));
    return user_credit;
}

void InputManager::take_input() {
    string data;
    getline(cin, data);
    vector<string> input = split_string(data, ' ');
    if (input[0] == "show_author_info") {
        show_author_info(stoi(input[1]));
    } else if (input[0] == "show_sorted_shelf") {
        int user_id = stoi(input[1]);
        string shelf_type = input[2];
        string genre = input[3];
        if (shelf_type == "want_to_read") {
            show_sorted_shelf(user_id, WANT_TO_READ, genre);
        } else if (shelf_type == "currently_reading") {
            show_sorted_shelf(user_id, CURRENTLY_READING, genre);
        } else {
            show_sorted_shelf(user_id, READ, genre);
        }
    } else if (input[0] == "credit") {
        int user_id = stoi(input[1]);
        double user_credit = calculate_user_credit(user_id);
        cout << setprecision(4) << user_credit << endl;
    }
}