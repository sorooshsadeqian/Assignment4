#ifndef STORAGE_HPP
#define STORAGE_HPP "STORAGE_HPP"

#include <vector>
#include <string>
#include <fstream>
#include "functions.hpp"
#include "Author.hpp"
#include "Book.hpp"
#include "User.hpp"
#include "Review.hpp"

class Storage {
public:
    void add_book(Book* book);
    void add_author(Author* author);
    void add_user(User* user);
    void add_review(Review* review);
    void read_authors_info(std::string file_path);
    void read_books_info(std::string file_path);
    void read_users_info(std::string file_path);
    void read_reviews_info(std::string file_path);
    std::vector<Author*> arrange_authors(std::string data);
    Shelf* make_shelf(std::string data);
    Book* get_book_by_id(int book_id);
    Author* get_author_by_id(int author_id);
    User* get_user_by_id(int user_id);
    std::vector<Book*> get_author_books(int author_id);
    int calculate_total_likes();
    int calculate_uesr_reviews_likes(int user_id);
    int get_number_of_reviews();
    int get_number_of_user_reviews(int user_id);
private:
    std::vector<Book*> books;
    std::vector<Author*> authors;
    std::vector<User*> users;
    std::vector<Review*> reviews;
};

#endif