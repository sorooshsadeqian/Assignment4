#include "Author.hpp"

using namespace std;

Author::Author(int id, string name, string gender, Date* member_since, int year_of_birth, string place_of_birth, vector<string> genres) {
    this->id = id;
    this->name = name;
    this->gender = gender;
    this->place_of_birth = place_of_birth;
    this->year_of_birth = year_of_birth;
    this->genres = genres;
    this->member_since = member_since;
}

int Author::get_id() {
    return id;
}

string Author::get_name() {
    return name;
}

string Author::get_place_of_birth() {
    return place_of_birth;
}

int Author::get_year_of_birth() {
    return year_of_birth;
}

vector<string> Author::get_genres() {
    return genres;
}

Date* Author::get_membership_date() {
    return member_since;
}
