#include "Date.hpp"

using namespace std;

Date::Date(string month, int day, int year) {
    this->month = month;
    this->day = day;    
    this->year = year; 
}

Date::Date(string unsplit_date) {
    vector<string> splited_date = split_string(unsplit_date, ' ');
    month = splited_date[0];
    day = stoi(splited_date[1]);
    year = stoi(splited_date[2]);
}

void Date::print() {
    cout << month << ' ' << day << ' ' << year << endl;
}
