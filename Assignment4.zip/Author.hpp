#ifndef AUTHOR_HPP
#define AUTHOR_HPP "AUTHOR_HPP"

#include <string>
#include <vector>

class Date;

class Author {
public:
    Author(int id, std::string name, std::string gender, Date* member_since, int year_of_birth, std::string place_of_birth, std::vector<std::string> genres);
    int get_id();
    int get_year_of_birth();
    std::string get_name();
    std::string get_place_of_birth();
    std::vector<std::string> get_genres();
    Date* get_membership_date();
private:
    int id;
    std::string name;
    std::string gender;
    Date* member_since;
    int year_of_birth;
    std::string place_of_birth;
    std::vector<std::string> genres;
};

#endif