#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP "FUNCTIONS_HPP"

#include <string>
#include <vector>

#include "Book.hpp"
#include <sstream>

std::vector<std::string> split_string(std::string data, char delim);
bool sort_by_title(Book* b1, Book* b2);

#endif