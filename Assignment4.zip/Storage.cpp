#include "Storage.hpp"

using namespace std;

void Storage::add_book(Book* book) {
    books.push_back(book);
}

void Storage::add_author(Author* author) {
    authors.push_back(author);
}

void Storage::add_user(User* user) {
    users.push_back(user);
}

void Storage::add_review(Review* review) {
    reviews.push_back(review);
}

vector<Book*> Storage::get_author_books(int author_id) {
    vector<Book*> author_books;
    for (int i = 0; i < books.size(); i++) {
        if (books[i]->get_author_id() == author_id) {
            author_books.push_back(books[i]);
        }
    }

    return author_books;
}

Author* Storage::get_author_by_id(int author_id) {
    for (int i = 0; i < authors.size(); i++) {
        if (authors[i]->get_id() == author_id) {
            return authors[i];
        }
    }

    return NULL;
}

Book* Storage::get_book_by_id(int book_id) {
    for (int i = 0; i < books.size(); i++) {
        if (book_id == books[i]->get_id()) {
            return books[i];
        }
    }

    return NULL;
}

User* Storage::get_user_by_id(int user_id) {
    for (int i = 0; i < users.size(); i++) {
        if (users[i]->get_id() == user_id) {
            return users[i];
        }
    }

    return NULL;
}

Shelf* Storage::make_shelf(string data) {
    vector<string> books_id = split_string(data, '$');
    Shelf* shelf = new Shelf();
    Book* temp;
    for (int i = 0; i < books_id.size(); i++) {
        temp = get_book_by_id(stoi(books_id[i]));
        shelf->add_book(temp);
    }

    return shelf;
}

vector<Author*> Storage::arrange_authors(string data) {
    vector<string> author_id = split_string(data, '$');
    vector<Author*> authors;
    Author* temp;
    for (int i = 0 ; i < author_id.size(); i++) {
        temp = get_author_by_id(stoi(author_id[i]));
        authors.push_back(temp);
    }

    return authors;
}

int Storage::calculate_total_likes() {
    int sum = 0;
    for (int i = 0; i < reviews.size(); i++) {
        sum += reviews[i]->get_number_of_likes();
    }

    return sum;
}

int Storage::calculate_uesr_reviews_likes(int user_id) {
    int sum = 0;
    for (int i = 0; i < reviews.size(); i++) {
        if (reviews[i]->get_user_id() == user_id) {
            sum += reviews[i]->get_number_of_likes();
        }
    }

    return sum;
}

int Storage::get_number_of_reviews() {
    return reviews.size();
}

int Storage::get_number_of_user_reviews(int user_id) {
    int sum = 0;
    for (int i = 0; i < reviews.size(); i++) {
        if (reviews[i]->get_user_id() == user_id) {
            sum++;
        }
    }

    return sum;
}

void Storage::read_authors_info(string file_path) {
    fstream author_csv(file_path);
    int id, year_of_birth;
    string data, name, gender, place_of_birth, unsplited_genres, date;
    getline(author_csv, data);
    while (getline(author_csv, data)) {
        vector<string> author_info = split_string(data, ',');
        id = stoi(author_info[0]);
        name = author_info[1];
        gender = author_info[2];
        date = author_info[3];
        Date* member_since = new Date(date);
        year_of_birth = stoi(author_info[4]);
        place_of_birth = author_info[5];
        unsplited_genres = author_info[6];
        vector<string> genres = split_string(unsplited_genres, '$');
        Author* new_author = new Author(id, name, gender, member_since, year_of_birth, place_of_birth, genres);
        add_author(new_author);
    }

    author_csv.close();
}

void Storage::read_books_info(string file_path) {
    fstream book_csv(file_path);
    int id;
    string data, title, genre;
    getline(book_csv, data);
    while (getline(book_csv, data)) {
        vector<string> book_info = split_string(data, ',');
        id = stoi(book_info[0]);
        title = book_info[1];
        Author* author = get_author_by_id(stoi(book_info[2]));
        genre = book_info[3];
        Book* new_book = new Book(id, title, author, genre);
        add_book(new_book);
    } 

    book_csv.close();
}

void Storage::read_users_info(string file_path) {
    fstream users_csv(file_path);
    int id;
    string data, name,  place_of_birth;
    getline(users_csv, data);
    while (getline(users_csv, data)) {
        vector<string> user_info = split_string(data, ',');
        id = stoi(user_info[0]);
        name = user_info[1];
        place_of_birth = user_info[2];
        Date* member_since = new Date(user_info[3]);
        vector<Author*> favorite_authors = arrange_authors(user_info[4]);
        vector<string> favorite_genres = split_string(user_info[5], '$');
        User* user = new User(id, name, place_of_birth, member_since, favorite_authors, favorite_genres);
        user->add_shelf(make_shelf(user_info[6]));
        user->add_shelf(make_shelf(user_info[7]));
        user->add_shelf(make_shelf(user_info[8]));
        add_user(user);
    }

    users_csv.close();
}

void Storage::read_reviews_info(string file_path) {
    fstream reviews_csv(file_path);
    string data;
    int id, rating, number_of_likes;
    getline(reviews_csv, data);
    while (getline(reviews_csv, data)) {
        vector<string> reviews_info = split_string(data, ',');
        id = stoi(reviews_info[0]);
        Book* book = get_book_by_id(stoi(reviews_info[1]));
        User* user = get_user_by_id(stoi(reviews_info[2]));
        rating = stoi(reviews_info[3]);
        Date* date = new Date(reviews_info[4]);
        number_of_likes = stoi(reviews_info[5]);
        Review* review = new Review(id, book, user, rating, date, number_of_likes);
        add_review(review);
    }
    
    reviews_csv.close();
}