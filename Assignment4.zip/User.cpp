#include "User.hpp"

using namespace std;

User::User(int id, string name, string place_of_birth, Date* member_since, vector<Author*> favorite_authors, vector<string> favorite_genres) {
    this->id = id;
    this->name = name;
    this->place_of_birth = place_of_birth;
    this->member_since = member_since;
    this->favorite_authors = favorite_authors;
    this->favorite_genres = favorite_genres;
}

void User::add_shelf(Shelf* new_shelf) {
    shelves.push_back(new_shelf);
}

int User::get_id() {
    return id;
}

Shelf* User::get_shelf(int shelf_id) {
    return shelves[shelf_id];
}
