#ifndef REVIEW_HPP
#define REVIEW_HPP "REVIEW_HPP"

#include "User.hpp"

class Book;
class Date;

class Review {
public:
    Review(int id, Book* book, User* user, int rating, Date* date, int number_of_likes);
    int get_number_of_likes();
    int get_user_id();
private:
    int id;
    Book* book;
    User* user;
    int rating;
    Date* date;
    int number_of_likes;
};

#endif