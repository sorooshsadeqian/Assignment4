#include <iostream>
#include <fstream>
#include <string>
#include "Storage.hpp"
#include "InputManager.hpp"

using namespace std;

int main(int argc, char* argv[]) {
    string Assets_path = argv[1];
    Storage* storage = new Storage();
    storage->read_authors_info(Assets_path + '/' + "authors.csv");
    storage->read_books_info(Assets_path + '/' + "books.csv");
    storage->read_users_info(Assets_path + '/' + "users.csv");
    storage->read_reviews_info(Assets_path + '/' + "reviews.csv");
    InputManager* input_manager = new InputManager(storage);
    input_manager->take_input(); 
}