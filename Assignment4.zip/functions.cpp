#include "functions.hpp"

using namespace std;

vector<string> split_string(string data, char delim) {
    vector<string> splited_data;
    stringstream stream(data);
    string temp;
    while (getline(stream, temp, delim)) {
        splited_data.push_back(temp);
    }

    return splited_data;
}

bool sort_by_title(Book* b1, Book* b2) {
    return (b1->get_title()) < (b2->get_title());
}